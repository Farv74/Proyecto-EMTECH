"""
This is the LifeStore-SalesList data:

lifestore-searches = [id_search, id product]
lifestore-sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
lifestore-products = [id_product, name, price, category, stock]
"""

from lifestore_file import lifestore_searches
from lifestore_file import lifestore_sales 
from lifestore_file import lifestore_products

#Inicio de sesion
#Usuarios = [[Usuario,Contraseña,Admin (1 for true or 0 to false)]]
# Solo los administradores pueden agregar a otro administrador

Usuarios = [["Fidel","123",1]]
bandera = 0 

print("Inicio de sesión")

while bandera == 0:
  usuario_inpt = input("\nUsuario: ")
  contraseña_inpt = input("Contraseña: ")
  for usuario in Usuarios:
    if usuario_inpt == usuario[0] and contraseña_inpt == usuario[1]:
      bandera = 1
      
    else:
      print("\nEl usuario no es correcto, vuelva a intentarlo")

#MENU
bandera = 0
print("\n¡Bienvenido "+ usuario_inpt+"!")
while bandera != 1:
  bandera = 0
  print("\n ¿Qué deseas ver?")
  print("1. Productos más vendidos y productos rezagados")
  print("2. Productos por reseña de servicio")
  print("3. Total de ingresos y ventas promedio mensuales, total anual y meses con más ventas al año")
  menu_opc = int(input("Seleccione una opción: "))
#1. Productos mas vendidos y productos rezagados
  if menu_opc == 1:
    while bandera != 2:
      bandera = 0
      print("\nProductos más vendidos y productos rezagados\n")
      print("1. Productos con mayores ventas")
      print("2. Productos con mayores busquedas")
      print("3. Menores ventas por categoria")
      print("4. Menores busquedas por categoria")
      print("5. Regresar a menu principal")
      menu1_opc = int(input("Seleccione una opción: "))
      
      if menu1_opc == 5:
        bandera = 2
    #1. Productos con mayoreres ventas
      if menu1_opc == 1:
        while bandera != 3:
          bandera = 0
          print("\nProductos con mayores ventas\n")
          print("1. Por numero de veces vendido")
          print("2. Por ventas generadas")
          print("3. Regresar a menu de productos más vendidos y productos rezagados")
          menu2_opc = int(input("Seleccione una opción: "))

          if menu2_opc == 3:
            bandera = 3

        #1. Por numero de veces vendido
          if menu2_opc == 1:
            contador = 0
            total_ventas = []
            ventas_ordenadas = []

            for producto in lifestore_products:
              for venta in lifestore_sales:
                if producto[0] == venta[1]:
                  contador += 1
              formato_ideal = [producto[0],producto[1],contador, producto[2], producto [3], producto [4]]
              #[id_product, name, ventas, price, category, stock]
              total_ventas.append(formato_ideal)
              contador = 0

            while total_ventas:
              maximo = total_ventas [0][2] 
              actual = total_ventas [0]
              for ventas in total_ventas :
                if ventas[2]> maximo:
                  maximo = ventas [2]
                  actual = ventas 
              ventas_ordenadas.append(actual)  
              total_ventas.remove(actual)

            print ("\nTop 50 productos mas vendidos\n")
            num=1
            for total in ventas_ordenadas:
              print(num,". El producto : ", total[1], "se vendio ", total [2], " veces. Venta total: $",float(total[2])*float(total[3]),".- pesos \n")
              num += 1
              if num >= 51:
                break

        #2. Por ventas generadas
          if menu2_opc == 2:
            contador = 0
            total_ventas = []
            ventas_ordenadas = []

            for producto in lifestore_products:
              for venta in lifestore_sales:
                if producto[0] == venta[1]:
                  contador += 1
              formato_ideal = [producto[0],producto[1],contador, producto[2], producto [3], producto [4], contador*producto[2]]
              #[id_product, name, numero de ventas, price, category, stock, monto ventas]
              total_ventas.append(formato_ideal)
              contador = 0

            while total_ventas:
              maximo = total_ventas [0][6]
              actual = total_ventas [0]
              for ventas in total_ventas :
                if ventas[6]> maximo:
                  maximo = ventas [6]
                  actual = ventas 
              ventas_ordenadas.append(actual)  
              total_ventas.remove(actual)

            print ("\nTop 50 productos mas vendidos\n")
            num=1
            for total in ventas_ordenadas:
              print(num,". \nEl producto : ", total[1], "\nSe vendio ", total [2], " veces. \nVenta total: $",float(total[2])*float(total[3]),".- pesos \nQuedan: ", total[5], "piezas en almacen \n")
              num += 1
              if num >= 51:
                break
    #2. Productos con mayores busquedas
      if menu1_opc == 2:
        contador = 0
        total_busquedas = []
        busquedas_ordenadas = []

        for producto in lifestore_products:
          for busqueda in lifestore_searches:
            if producto[0] == busqueda[1]:
              contador += 1
          formato_ideal = [producto[0],producto[1],contador]#[id_product, name, ventas]
          total_busquedas.append(formato_ideal)
          contador = 0

        while total_busquedas:
          maximo = total_busquedas [0][2] 
          actual = total_busquedas [0]
          for busqueda in total_busquedas :
            if busqueda[2]> maximo:
              maximo = busqueda [2]
              actual = busqueda 
          busquedas_ordenadas.append(actual)  
          total_busquedas.remove(actual)

        print ("\nTop 50 productos con mas busquedas\n")    
        num=1
        for total in busquedas_ordenadas:
          print(num,".\nEl producto :", total[1], "\nSe buscó: ", total [2], " veces.\n")
          num += 1
          if num >= 51:
            break 
    #3. Menores ventas por categoria
      if menu1_opc == 3:  
        contador = 0
        total_ventas = []
        ventas_ordenadas = []
        cat_unicos=[]

        for producto in lifestore_products:
          for venta in lifestore_sales:
            if producto[0] == venta[1]:
              contador += 1
          formato_ideal_ventas = [producto[0],producto[1],contador, producto[2], producto [3], producto [4]]
          #[id_product, name, ventas, price, category, stock]
          total_ventas.append(formato_ideal_ventas)
          contador = 0

        for categoria in total_ventas:
          if categoria[4] not in cat_unicos:
            cat_unicos.append(categoria[4])

        while total_ventas:
                min = total_ventas [0][2] 
                actual = total_ventas [0]
                for ventas in total_ventas :
                  if ventas[2]< min:
                    min = ventas [2]
                    actual = ventas 
                ventas_ordenadas.append(actual)  
                total_ventas.remove(actual)

        print("\nProductos por categoria ordenados de menor a mayor ventas\n")
        for categoria in cat_unicos:
          print("\n Categoria:",categoria)
          for producto in ventas_ordenadas:
            if categoria == producto[4]:
              print("El producto : ", producto[1], "se vendio ", producto [2], " veces. Venta total: $",float(producto[2])*float(producto[3]),".- pesos \n")
    #4. Menores busquedas por categoria
      if menu1_opc == 4:  
        contador = 0
        total_busquedas = []
        busquedas_ordenadas = []
        cat_unicos=[]

        for producto in lifestore_products:
          for busqueda in lifestore_searches:
            if producto[0] == busqueda[1]:
              contador += 1
          formato_ideal = [producto[0],producto[1],contador, producto[2], producto [3], producto [4]]
          #[id_product, name, ventas, price, category, stock]
          total_busquedas.append(formato_ideal)
          contador = 0

        for categoria in total_busquedas:
          if categoria[4] not in cat_unicos:
            cat_unicos.append(categoria[4])

        while total_busquedas:
                min = total_busquedas [0][2] 
                actual = total_busquedas [0]
                for busquedas in total_busquedas :
                  if busquedas[2]< min:
                    min = busquedas [2]
                    actual = busquedas 
                busquedas_ordenadas.append(actual)  
                total_busquedas.remove(actual)

        print("\nProductos por categoria ordenados de menor a mayor ventas\n")
        for categoria in cat_unicos:
          print("\n Categoria:",categoria)
          for producto in busquedas_ordenadas:
            if categoria == producto[4]:
              print("\nEl producto :", producto[1], "\nSe buscó: ", producto[2], " veces.\n")
#2. Productos por reseña de servicio
  if menu_opc == 2:
    while bandera != 2:
      bandera = 0
      print("\nProductos por reseña de servicio \n")
      print("1. Productos con mejores reseñas")
      print("2. Productos con peores reseñas")
      print("3. Regresar a menu principal")
      menu2_opc = int(input("Seleccione una opción: "))

      if menu2_opc == 3:
        bandera = 3

      contador = 0
      total_ventas = []
      ventas_ordenadas_max = []
      ventas_ordenadas_min = []

      for producto in lifestore_products:
        for venta in lifestore_sales:
          if producto[0] == venta[1]:
            contador += 1
        formato_ideal = [producto[0],producto[1],contador, producto[2], producto [3], producto [4], venta [2],venta [3], venta [4]]
        #[id_product, name, ventas, price, category, stock, score,date, refund]
        total_ventas.append(formato_ideal)
        contador = 0
  
    #1. Productos con mejores reseñas  
      if menu2_opc==1:
        while total_ventas:
          maximo = total_ventas [0][6] 
          actual = total_ventas [0]
          for ventas in total_ventas :
            if ventas[6]> maximo:
              maximo = ventas [6]
              actual = ventas 
          ventas_ordenadas_max.append(actual)  
          total_ventas.remove(actual)
        
        print ("\n20 productos con mejores reseñas\n")
        num=1
        for total in ventas_ordenadas_max:
          print(num,". El producto : ", total[1], "\nReseña: ", total [6], "\n Refund: ",total [8])
          num += 1
          if num >= 61:
            break


    #2. Productos con peores reseñas
      if menu2_opc==2:
        while total_ventas:
          minimo = total_ventas [0][6] 
          actual = total_ventas [0]
          for ventas in total_ventas :
            if ventas[6]< minimo:
              minimo = ventas [6]
              actual = ventas 
          ventas_ordenadas_min.append(actual)  
          total_ventas.remove(actual)
        
        print ("\n20 productos con peores reseñas\n")
        num=1
        for total in ventas_ordenadas_min:
          print(num,". El producto : ", total[1], "\nReseña: ", total [6], "\n Refund: ",total [8])
          num +=1
          if num >= 21:
            break
#3. Ingresos
  if menu_opc == 3:

    bandera = 0
    print("\nIngresos\n")

    contador = 0
    total_ventas = []
    ventas_ordenadas = []
    mes_unicos = []
    año_unicos=[]


    for producto in lifestore_products:
      for venta in lifestore_sales:
        if producto[0] == venta[1]:
          contador += 1
      formato_ideal = [producto[0],producto[1],contador, producto[2], producto [3], producto [4], contador*producto[2]]
      #[id_product, name, numero de ventas, price, category, stock, monto ventas]
      total_ventas.append(formato_ideal)
      contador = 0

    suma_ingresos = 0
    for venta in total_ventas:
      suma_ingresos += venta[6]
    print("\nVentas totales:  $", suma_ingresos,".- pesos\n")

    for date in lifestore_sales:
      if date[3][3:10] not in mes_unicos:
       mes_unicos.append(date[3][3:10])
    print("Promedio mensual $",suma_ingresos/len(mes_unicos),".- pesos\n")

    for date in lifestore_sales:
      if date[3][6:10] not in año_unicos:
        año_unicos.append(date[3][6:10])
    print(año_unicos)

    suma_anual = 0
    for año in año_unicos:
      for producto in total_ventas:
        suma_anual += producto 


